package com.clsaa.edu.java.effective.chapter01.item05;

import java.util.HashMap;
import java.util.Map;

public class TestMapSet {
    public static void main(String[] args) {
        HashMap<String,String> map = new HashMap<String, String>();
        map.put("123", "!@3");
        map.entrySet();
        map.entrySet();
    }
}
