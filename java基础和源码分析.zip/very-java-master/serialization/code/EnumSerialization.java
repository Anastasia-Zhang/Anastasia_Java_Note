public enum EnumSerialization{
  LIGHT,
  DARK;
  EnumSerialization() {

  }
}