public class Config{
  private String x;
  Config(String x){
    this.x = x;
  }
}